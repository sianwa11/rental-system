package rentalmanagement;
public class client {
   public int Client_ID;
   public String Client_firstname;
   public String Client_lastname;
   public String Client_phonenumber;
   public String Client_email;
   public String Client_password;
   public String Complaint_description;

   
   public client(int Client_ID,String Client_firstname,String Client_lastname,String Client_phonenumber,String Client_email,String Client_password,String Complaint_description){
       this.Client_ID=Client_ID;
       this.Client_firstname=Client_firstname;
       this.Client_lastname=Client_lastname;
       this.Client_phonenumber=Client_phonenumber;
       this.Client_email=Client_email;
       this.Client_password=Client_password;
       this.Complaint_description=Complaint_description;;
    
       
   }
   
   public int getClient_ID(){
       return Client_ID;
   }
   
    public String getClient_firstname(){
       return Client_firstname;
   }
    
     public String getClient_lastname(){
       return Client_lastname;
   }
     
      public String getClient_phonenumber(){
       return Client_phonenumber;
   }
      
       public String getClient_email(){
       return Client_email;
   }
    
       
        public String getComplaint_description(){
       return Complaint_description;
   }
        
              public String getClient_password(){
       return Client_password;
   }
      
}
