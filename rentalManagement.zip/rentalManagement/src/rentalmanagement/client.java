package rentalmanagement;
public class client {
     private int clientID,phoneNumber,contractID;
    private String firstName,lastName,email,houseType;
    
    public client(int clientID,int phoneNumber,int contractID,String firstName,String lastName,String email,String houseType){
    
    this.contractID=contractID;
    this.phoneNumber=phoneNumber;
    this.firstName=firstName;
    this.lastName=lastName;
    this.houseType=houseType;
    }
    public int getClientId(){
    return clientID;}
    public String gethouseType(){
    return houseType;}
    public String getfirstName(){
    return firstName;}
    public String getlastName(){
    return lastName;}
    public String getemail(){
    return email;}
}
