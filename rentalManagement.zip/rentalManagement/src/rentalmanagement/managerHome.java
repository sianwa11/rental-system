/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalmanagement;

import java.awt.Image;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author EDALIA. M
 */
public class managerHome extends javax.swing.JFrame {
    private Connection conn;
    private Statement st;
    private ResultSet rs;
    String filename=null;//stores location of the image
    byte[] supervisor_image=null;//stores image

    /**
     * Creates new form managerHome
     */
    public managerHome() {
        initComponents();
    }

    //
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        logout = new javax.swing.JButton();
        greetingLabel = new javax.swing.JTextField();
        logo = new javax.swing.JLabel();
        userHome = new javax.swing.JLabel();
        confirm = new javax.swing.JButton();
        viewProperty = new javax.swing.JLabel();
        viewComments = new javax.swing.JLabel();
        password_change = new javax.swing.JLabel();
        changePasswordtxt = new javax.swing.JPasswordField();
        password_label1 = new javax.swing.JLabel();
        assignLandlord1 = new javax.swing.JLabel();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Manager:Home");
        setBounds(new java.awt.Rectangle(0, 0, 1300, 700));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel1.setLayout(null);

        logout.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        logout.setText("Logout");
        logout.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });
        panel1.add(logout);
        logout.setBounds(40, 30, 110, 50);

        greetingLabel.setEditable(false);
        greetingLabel.setBackground(new java.awt.Color(0, 51, 102));
        greetingLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        greetingLabel.setForeground(new java.awt.Color(255, 255, 255));
        greetingLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        greetingLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                greetingLabelActionPerformed(evt);
            }
        });
        panel1.add(greetingLabel);
        greetingLabel.setBounds(410, 10, 260, 60);

        logo.setFont(new java.awt.Font("Viner Hand ITC", 1, 18)); // NOI18N
        logo.setForeground(new java.awt.Color(204, 204, 204));
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/Home.png"))); // NOI18N
        logo.setText("R.M.S");
        panel1.add(logo);
        logo.setBounds(1130, 0, 149, 90);

        userHome.setBackground(new java.awt.Color(0, 51, 102));
        userHome.setOpaque(true);
        panel1.add(userHome);
        userHome.setBounds(0, 0, 1300, 100);

        confirm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        confirm.setText("Confirm Change");
        confirm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                confirmMouseClicked(evt);
            }
        });
        confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmActionPerformed(evt);
            }
        });
        panel1.add(confirm);
        confirm.setBounds(950, 240, 150, 40);

        viewProperty.setBackground(new java.awt.Color(204, 204, 204));
        viewProperty.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        viewProperty.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/vacancy.png"))); // NOI18N
        viewProperty.setText("View Property");
        viewProperty.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        viewProperty.setOpaque(true);
        viewProperty.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewPropertyMouseClicked(evt);
            }
        });
        panel1.add(viewProperty);
        viewProperty.setBounds(30, 530, 240, 130);

        viewComments.setBackground(new java.awt.Color(204, 204, 204));
        viewComments.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        viewComments.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/staff-png-image-58876.png"))); // NOI18N
        viewComments.setText("View Comments");
        viewComments.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        viewComments.setOpaque(true);
        viewComments.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewCommentsMouseClicked(evt);
            }
        });
        panel1.add(viewComments);
        viewComments.setBounds(30, 330, 240, 130);

        password_change.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        password_change.setText("Change Password:");
        panel1.add(password_change);
        password_change.setBounds(880, 180, 150, 30);
        panel1.add(changePasswordtxt);
        changePasswordtxt.setBounds(1010, 180, 160, 20);

        password_label1.setBackground(new java.awt.Color(204, 204, 204));
        password_label1.setOpaque(true);
        panel1.add(password_label1);
        password_label1.setBounds(830, 120, 380, 200);

        assignLandlord1.setBackground(new java.awt.Color(204, 204, 204));
        assignLandlord1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        assignLandlord1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/supervisors.png"))); // NOI18N
        assignLandlord1.setText("Assign Supervisor");
        assignLandlord1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        assignLandlord1.setOpaque(true);
        assignLandlord1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                assignLandlord1MouseClicked(evt);
            }
        });
        panel1.add(assignLandlord1);
        assignLandlord1.setBounds(30, 140, 240, 130);

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/Base.png"))); // NOI18N
        panel1.add(background);
        background.setBounds(0, 0, 1300, 700);

        getContentPane().add(panel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 700));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        new userLogin().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutActionPerformed

    private void greetingLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_greetingLabelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_greetingLabelActionPerformed

    private void assignLandlord1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_assignLandlord1MouseClicked
        new assignSupervisor().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_assignLandlord1MouseClicked

    private void viewCommentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewCommentsMouseClicked
        new viewComments().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_viewCommentsMouseClicked

    private void viewPropertyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPropertyMouseClicked
       new totalProperty().setVisible(true);
       this.dispose();
    }//GEN-LAST:event_viewPropertyMouseClicked

    private void confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_confirmActionPerformed

    private void confirmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmMouseClicked
        // TODO add your handling code here:
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost/rental ii","root","");
            String query="UPDATE  manager SET Manager_password=?";
            PreparedStatement pst=conn.prepareStatement(query);
            pst.setString(1,changePasswordtxt.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"Updated successfully");
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }//GEN-LAST:event_confirmMouseClicked

    //
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(managerHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(managerHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(managerHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(managerHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new managerHome().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel assignLandlord1;
    private javax.swing.JLabel background;
    private javax.swing.JPasswordField changePasswordtxt;
    private javax.swing.JButton confirm;
    private javax.swing.JTextField greetingLabel;
    private javax.swing.JLabel logo;
    private javax.swing.JButton logout;
    private java.awt.Panel panel1;
    private javax.swing.JLabel password_change;
    private javax.swing.JLabel password_label1;
    private javax.swing.JLabel userHome;
    private javax.swing.JLabel viewComments;
    private javax.swing.JLabel viewProperty;
    // End of variables declaration//GEN-END:variables
}
