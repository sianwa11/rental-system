/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalmanagement;

/**
 *
 * @author saate
 */
class Viewsupervisors {
    private int Supervisor_ID;
    private String Supervisor_firstname,Supervisor_lastname,Supervisor_phonenumber,Location_address;
    private byte[] Supervisor_image;
     
    public Viewsupervisors(int Supervisor_ID,String Supervisor_firstname,String Supervisor_lastname,String Supervisor_phonenumber,String Location_address,byte[]Supervisor_image){
        
        
       this.Supervisor_ID=Supervisor_ID;
       this.Supervisor_firstname=Supervisor_firstname;
       this.Supervisor_lastname=Supervisor_lastname;
       this.Supervisor_phonenumber=Supervisor_phonenumber;
       this.Location_address=Location_address;
       this.Supervisor_image=Supervisor_image;
    }
    
    public int getSupervisor_ID(){
        return Supervisor_ID;
    }
    
    public String getSupervisor_firstname(){
        return Supervisor_firstname;
    }
    
    public String getSupervisor_lastname(){
        return Supervisor_lastname;
    }
    
    public String getSupervisor_phonenumber(){
        return Supervisor_phonenumber;
    }
    
    public String getLocation_address(){
        return Location_address;
    }
    
    public byte[] getSupervisor_image(){
        return Supervisor_image;
    }
    
}
