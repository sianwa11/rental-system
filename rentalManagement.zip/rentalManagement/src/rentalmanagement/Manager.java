/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalmanagement;

/**
 *
 * @author saate
 */
class Manager {
    public int houseID;
    public String houseType;
    public int houseNumber;
    
    public Manager(int houseID,int houseNumber,String houseType){
        this.houseID=houseID;
        this.houseType=houseType;
        this.houseNumber=houseNumber;
    }
    
    public int gethouseID(){
        return houseID;
    }
    public String gethouseType(){
        return houseType;
    }
    public int gethouseNumber(){
        return houseNumber;
    }
    
}
