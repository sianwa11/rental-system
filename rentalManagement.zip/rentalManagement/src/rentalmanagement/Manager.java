/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalmanagement;

/**
 *
 * @author saate
 */
class Manager {
    public int Property_ID;
    public String Property_number;
    public String Property_type;
    public String Location_address;
   
    
    public Manager(int Property_ID, String Property_number,String Property_type,String Location_address){
        this.Property_ID=Property_ID;
        this.Property_number=Property_number;
        this.Property_type=Property_type;
        this.Location_address=Location_address;
        
    }
    
    public int getProperty_ID(){
        return Property_ID;
    }
    public String getProperty_number(){
        return Property_number;
    }
    public String getProperty_type(){
        return Property_type;
    }
    public String getLocation_address(){
        return Location_address;
    }
    
}
