package rentalmanagement;
import java.awt.Image;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class assignSupervisor extends javax.swing.JFrame {
    
    private Connection conn;
    private Statement st;
    private ResultSet rs;
    String filename=null;//stores location of the image
    byte[] supervisor_image=null;//stores image
    
//Creates new form assignTenant
    public assignSupervisor() {
        initComponents();
        viewsupervisors();
        
    }
    public ArrayList<Viewsupervisors> supervisorsList(){
        ArrayList<Viewsupervisors> supervisorsList= new ArrayList<>();
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost/rental ii","root","");
            String query="SELECT * FROM supervisor";
            Statement st=conn.createStatement();
            ResultSet rs=st.executeQuery(query);
            Viewsupervisors  viewsupervisors;
            while(rs.next()){
                viewsupervisors=new Viewsupervisors(rs.getInt("Supervisor_ID"),rs.getString("Supervisor_firstname"),rs.getString("Supervisor_lastname"),rs.getString("Supervisor_phonenumber"),rs.getString("Location_address"),rs.getBytes("Supervisor_image"));
                supervisorsList.add(viewsupervisors);
            }
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return supervisorsList;
    }
    
    public void viewsupervisors(){
        ArrayList<Viewsupervisors> list= supervisorsList();
        DefaultTableModel model=(DefaultTableModel)jTable_viewsupervisor.getModel();
        Object[] row=new Object[5];
        for(int i=0;i<list.size();i++){
            row[0]=list.get(i).getSupervisor_ID();
            row[1]=list.get(i).getSupervisor_firstname();
            row[2]=list.get(i).getSupervisor_lastname();
            row[3]=list.get(i).getSupervisor_phonenumber();
            row[4]=list.get(i).getLocation_address();
            model.addRow(row);//Adds a row to the end of the model
           
        }
        
    }
    
    
   
    
 
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel2 = new java.awt.Panel();
        logo = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        userHome = new javax.swing.JLabel();
        firstName = new javax.swing.JLabel();
        phoneNumber = new javax.swing.JLabel();
        lastName = new javax.swing.JLabel();
        lastnametxt = new javax.swing.JTextField();
        phonenumbertxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        passwordfield = new javax.swing.JPasswordField();
        locationtxt = new javax.swing.JTextField();
        Choosebtn = new javax.swing.JButton();
        confirm = new javax.swing.JButton();
        imagelbl = new javax.swing.JLabel();
        updatebtn = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        firstnametxt = new javax.swing.JTextField();
        assignTable = new javax.swing.JScrollPane();
        jTable_viewsupervisor = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Assign Supervisor");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logo.setFont(new java.awt.Font("Viner Hand ITC", 1, 18)); // NOI18N
        logo.setForeground(new java.awt.Color(204, 204, 204));
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/Home.png"))); // NOI18N
        logo.setText("R.M.S");
        panel2.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, -10, 170, 90));

        back.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        back.setText("< Back");
        back.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        panel2.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 100, 50));

        userHome.setBackground(new java.awt.Color(0, 51, 102));
        userHome.setOpaque(true);
        panel2.add(userHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 90));

        firstName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        firstName.setText("First name:");
        panel2.add(firstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, -1, -1));

        phoneNumber.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        phoneNumber.setText("Phone Number:");
        panel2.add(phoneNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 330, -1, -1));

        lastName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lastName.setText("Last name:");
        panel2.add(lastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, -1, -1));

        lastnametxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(lastnametxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 170, -1));

        phonenumbertxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(phonenumbertxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 330, 170, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Insert Password:");
        jLabel3.setToolTipText("");
        panel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, 130, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Location:");
        panel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 380, -1, -1));

        passwordfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordfieldActionPerformed(evt);
            }
        });
        panel2.add(passwordfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 420, 170, -1));

        locationtxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(locationtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 380, 170, -1));

        Choosebtn.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        Choosebtn.setText("Choose");
        Choosebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ChoosebtnMouseClicked(evt);
            }
        });
        Choosebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChoosebtnActionPerformed(evt);
            }
        });
        panel2.add(Choosebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 430, -1, 30));

        confirm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        confirm.setText("Save");
        confirm.setToolTipText("");
        confirm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                confirmMouseClicked(evt);
            }
        });
        confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmActionPerformed(evt);
            }
        });
        panel2.add(confirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 490, 90, 50));

        imagelbl.setOpaque(true);
        imagelbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                imagelblMouseClicked(evt);
            }
        });
        panel2.add(imagelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 274, 260, 280));

        updatebtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        updatebtn.setText("Update");
        updatebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updatebtnMouseClicked(evt);
            }
        });
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        panel2.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 490, 90, 50));

        delete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        delete.setForeground(new java.awt.Color(255, 0, 0));
        delete.setText("Delete record");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        panel2.add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 490, 130, 50));

        firstnametxt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(firstnametxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 170, -1));

        jTable_viewsupervisor.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable_viewsupervisor.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable_viewsupervisor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Supervisor ID", "First Name", "Last name", "Phone number", "Location"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_viewsupervisor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_viewsupervisorMouseClicked(evt);
            }
        });
        assignTable.setViewportView(jTable_viewsupervisor);
        if (jTable_viewsupervisor.getColumnModel().getColumnCount() > 0) {
            jTable_viewsupervisor.getColumnModel().getColumn(0).setResizable(false);
            jTable_viewsupervisor.getColumnModel().getColumn(0).setHeaderValue("Supervisor ID");
            jTable_viewsupervisor.getColumnModel().getColumn(1).setResizable(false);
            jTable_viewsupervisor.getColumnModel().getColumn(1).setHeaderValue("First Name");
            jTable_viewsupervisor.getColumnModel().getColumn(2).setResizable(false);
            jTable_viewsupervisor.getColumnModel().getColumn(2).setHeaderValue("Last name");
            jTable_viewsupervisor.getColumnModel().getColumn(3).setResizable(false);
            jTable_viewsupervisor.getColumnModel().getColumn(3).setHeaderValue("Phone number");
            jTable_viewsupervisor.getColumnModel().getColumn(4).setResizable(false);
            jTable_viewsupervisor.getColumnModel().getColumn(4).setHeaderValue("Location");
        }

        panel2.add(assignTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 100, 500, 110));

        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setOpaque(true);
        panel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 420, 450));

        background.setBackground(new java.awt.Color(0, 255, 255));
        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/Base.png"))); // NOI18N
        background.setText("Choose");
        background.setOpaque(true);
        panel2.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(panel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 700));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        new managerHome().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    private void confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmActionPerformed
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost/rental ii","root","");
            String query="insert into supervisor(Supervisor_firstname,Supervisor_lastname,Supervisor_phonenumber,Location_address,Supervisor_password)values(?,?,?,?,?)";
            PreparedStatement pst=conn.prepareStatement(query);
            pst.setString(1,firstnametxt.getText());
            pst.setString(2,lastnametxt.getText());
            pst.setString(3,phonenumbertxt.getText());
            pst.setString(4,locationtxt.getText());
            pst.setString(5,passwordfield.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null,"done");
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        
        DefaultTableModel model=(DefaultTableModel)jTable_viewsupervisor.getModel();
        //checks whether there is input in respective textfields
        /*if(!idSuppervisor.getText().trim().equals("")&& !firstnametxt.getText().trim().equals("")&&!lastnametxt.getText().trim().equals("")&&!phonenumbertxt.getText().trim().equals("")&&!locationtxt.getText().trim().equals(""))
        {model.addRow(new String[]{idSuppervisor.getText(),firstnametxt.getText(),lastnametxt.getText(),phonenumbertxt.getText(),locationtxt.getText()});
    }//GEN-LAST:event_confirmActionPerformed
        else{//displays error message if textfields are left empty
            JOptionPane.showMessageDialog(null,"Fields cannot be left empty");
        }}*/
    }
    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed

    }//GEN-LAST:event_updatebtnActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        int option=JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(option==0){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost/rental ii","root","");
            int row=jTable_viewsupervisor.getSelectedRow();
            String value=(jTable_viewsupervisor.getModel().getValueAt(row,0).toString());
            String query="DELETE FROM supervisor where Supervisor_ID="+value;
            PreparedStatement pst=conn.prepareStatement(query);
            pst.executeUpdate();
            DefaultTableModel model=(DefaultTableModel)jTable_viewsupervisor.getModel();
            model.setRowCount(0);
            viewsupervisors();
            JOptionPane.showMessageDialog(null,"Delete Successful");
            
          }catch(Exception e){
              JOptionPane.showMessageDialog(null,e);
          }
        }
    }//GEN-LAST:event_deleteActionPerformed

    private void jTable_viewsupervisorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_viewsupervisorMouseClicked
        // TODO add your handling code here:
        int i =jTable_viewsupervisor.getSelectedRow();
        TableModel model=jTable_viewsupervisor.getModel();
        firstnametxt.setText(model.getValueAt(i,1).toString());
        lastnametxt.setText(model.getValueAt(i,2).toString());
        phonenumbertxt.setText(model.getValueAt(i,3).toString());
        locationtxt.setText(model.getValueAt(i,4).toString());
         byte[] img = ( supervisorsList().get(i).getSupervisor_image());
        ImageIcon imageicon=new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(imagelbl.getWidth(),imagelbl.getHeight(),Image.SCALE_SMOOTH));//SCALE_SMOOTH..Choose an image-scaling algorithm that gives higher priority to image smoothness than scaling speed.
        imagelbl.setIcon(imageicon);
     
        
        
        
        
    }//GEN-LAST:event_jTable_viewsupervisorMouseClicked

    
    private void updatebtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updatebtnMouseClicked
        // TODO add your handling code here
         DefaultTableModel model=(DefaultTableModel)jTable_viewsupervisor.getModel();
       try{
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost/rental ii","root","");
            int row=jTable_viewsupervisor.getSelectedRow();
            String value=(jTable_viewsupervisor.getModel().getValueAt(row,0).toString());
            String query="UPDATE supervisor SET Supervisor_firstname=?,Supervisor_lastname=?,Supervisor_phonenumber=?,Location_address=?,Supervisor_password=? where Supervisor_ID="+value;
            PreparedStatement pst=conn.prepareStatement(query);
            pst.setString(1,firstnametxt.getText());
            pst.setString(2,lastnametxt.getText());
            pst.setString(3,phonenumbertxt.getText());
            pst.setString(4,locationtxt.getText());
            pst.setString(5,passwordfield.getText());
            pst.executeUpdate();
            model.setRowCount(0);
            viewsupervisors();
            JOptionPane.showMessageDialog(null,"Updated Successfully");
            
            
            
       }catch(Exception e){
           JOptionPane.showMessageDialog(null,e);
       }
    }//GEN-LAST:event_updatebtnMouseClicked

    private void ChoosebtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ChoosebtnMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_ChoosebtnMouseClicked

    private void ChoosebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChoosebtnActionPerformed
        // TODO add your handling code here:
        JFileChooser chooser=new JFileChooser();
        chooser.showOpenDialog(null);//pops up"open file"
        File f = chooser.getSelectedFile();
        filename=f.getAbsolutePath();//returns absolute pathname
        ImageIcon imageicon=new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(imagelbl.getWidth(),imagelbl.getHeight(),Image.SCALE_SMOOTH));//SCALE_SMOOTH..Choose an image-scaling algorithm that gives higher priority to image smoothness than scaling speed.
        imagelbl.setIcon(imageicon);
        try{
            File image=new File(filename);
            FileInputStream finst=new FileInputStream(image);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buff  = new byte[1024];
            for(int readNum;(readNum=finst.read(buff)) !=-1;){
                bos.write(buff,0,readNum);
            }
              supervisor_image=bos.toByteArray();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }//GEN-LAST:event_ChoosebtnActionPerformed

    private void imagelblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagelblMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_imagelblMouseClicked

    private void passwordfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordfieldActionPerformed

    private void confirmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_confirmMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(assignSupervisor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(assignSupervisor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(assignSupervisor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(assignSupervisor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new assignSupervisor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Choosebtn;
    private javax.swing.JScrollPane assignTable;
    private javax.swing.JButton back;
    private javax.swing.JLabel background;
    private javax.swing.JButton confirm;
    private javax.swing.JButton delete;
    private javax.swing.JLabel firstName;
    private javax.swing.JTextField firstnametxt;
    private javax.swing.JLabel imagelbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTable jTable_viewsupervisor;
    private javax.swing.JLabel lastName;
    private javax.swing.JTextField lastnametxt;
    private javax.swing.JTextField locationtxt;
    private javax.swing.JLabel logo;
    private java.awt.Panel panel2;
    private javax.swing.JPasswordField passwordfield;
    private javax.swing.JLabel phoneNumber;
    private javax.swing.JTextField phonenumbertxt;
    private javax.swing.JButton updatebtn;
    private javax.swing.JLabel userHome;
    // End of variables declaration//GEN-END:variables
}
