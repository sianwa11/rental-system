package rentalmanagement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class assignSupervisor extends javax.swing.JFrame {
//Creates new form assignTenant
    public assignSupervisor() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel2 = new java.awt.Panel();
        logo = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        userHome = new javax.swing.JLabel();
        suppervisorID = new javax.swing.JLabel();
        firstName = new javax.swing.JLabel();
        idSuppervisor = new javax.swing.JTextField();
        phoneNumber = new javax.swing.JLabel();
        lastName = new javax.swing.JLabel();
        nameLast = new javax.swing.JTextField();
        phone_number = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        location_input = new javax.swing.JTextField();
        confirm = new javax.swing.JButton();
        update = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        nameFirst = new javax.swing.JTextField();
        assignTable = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Assign Supervisor");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logo.setFont(new java.awt.Font("Viner Hand ITC", 1, 18)); // NOI18N
        logo.setForeground(new java.awt.Color(204, 204, 204));
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/Home.png"))); // NOI18N
        logo.setText("R.M.S");
        panel2.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, -10, 170, 90));

        back.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        back.setText("< Back");
        back.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        panel2.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 100, 50));

        userHome.setBackground(new java.awt.Color(0, 51, 102));
        userHome.setOpaque(true);
        panel2.add(userHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 90));

        suppervisorID.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        suppervisorID.setText("Supervisor ID:");
        panel2.add(suppervisorID, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, -1, -1));

        firstName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        firstName.setText("First name:");
        panel2.add(firstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, -1, -1));

        idSuppervisor.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(idSuppervisor, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 170, -1));

        phoneNumber.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        phoneNumber.setText("Phone Number:");
        panel2.add(phoneNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, -1, -1));

        lastName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lastName.setText("Last name:");
        panel2.add(lastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, -1, -1));

        nameLast.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(nameLast, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, 170, -1));

        phone_number.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(phone_number, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 370, 170, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Location:");
        panel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 430, -1, -1));

        location_input.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(location_input, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 420, 170, -1));

        confirm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        confirm.setText("Confirm");
        confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmActionPerformed(evt);
            }
        });
        panel2.add(confirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 490, 90, 50));

        update.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        panel2.add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 130, 90, 70));

        delete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        delete.setForeground(new java.awt.Color(255, 0, 0));
        delete.setText("Delete record");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        panel2.add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 240, 130, 60));

        nameFirst.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        panel2.add(nameFirst, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 170, -1));

        jTable1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Supervisor ID", "First Name", "Last name", "Phone number", "Location"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        assignTable.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
        }

        panel2.add(assignTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 110, 500, 220));

        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setOpaque(true);
        panel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 420, 450));

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rentalmanagement/Base.png"))); // NOI18N
        panel2.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(panel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 700));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        new managerHome().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    private void confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmActionPerformed
        DefaultTableModel model=(DefaultTableModel)jTable1.getModel();
        //checks whether there is input in respective textfields
        if(!idSuppervisor.getText().trim().equals("")&& !nameFirst.getText().trim().equals("")&&!nameLast.getText().trim().equals("")&&!phone_number.getText().trim().equals("")&&!location_input.getText().trim().equals(""))
        {model.addRow(new String[]{idSuppervisor.getText(),nameFirst.getText(),nameLast.getText(),phone_number.getText(),location_input.getText()});
    }//GEN-LAST:event_confirmActionPerformed
        else{//displays error message if textfields are left empty
            JOptionPane.showMessageDialog(null,"Fields cannot be left empty");
        }}
    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
      DefaultTableModel model=(DefaultTableModel)jTable1.getModel();
 
    }//GEN-LAST:event_updateActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        DefaultTableModel model=(DefaultTableModel)jTable1.getModel();
        //deletes selected row containing records
       model.removeRow(jTable1.getSelectedRow());
    }//GEN-LAST:event_deleteActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(assignSupervisor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(assignSupervisor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(assignSupervisor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(assignSupervisor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new assignSupervisor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane assignTable;
    private javax.swing.JButton back;
    private javax.swing.JLabel background;
    private javax.swing.JButton confirm;
    private javax.swing.JButton delete;
    private javax.swing.JLabel firstName;
    private javax.swing.JTextField idSuppervisor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lastName;
    private javax.swing.JTextField location_input;
    private javax.swing.JLabel logo;
    private javax.swing.JTextField nameFirst;
    private javax.swing.JTextField nameLast;
    private java.awt.Panel panel2;
    private javax.swing.JLabel phoneNumber;
    private javax.swing.JTextField phone_number;
    private javax.swing.JLabel suppervisorID;
    private javax.swing.JButton update;
    private javax.swing.JLabel userHome;
    // End of variables declaration//GEN-END:variables
}
