/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalmanagement;

/**
 *
 * @author saate
 */
class Contractlist {
    private int Client_ID,Property_ID,Supervisor_ID,Maximum_rent,Rent_paid,Rent_due;
    public Contractlist(int Client_ID,int Property_ID,int Supervisor_ID,int Maximum_rent,int Rent_paid,int Rent_due){
        this.Client_ID=Client_ID;
        this.Property_ID=Property_ID;
        this.Supervisor_ID=Supervisor_ID;
        this.Maximum_rent=Maximum_rent;
        this.Rent_paid=Rent_paid;
        this.Rent_due=Rent_due;
        
    }
    
    public int getClient_ID(){
        return Client_ID;
    }
     
    public int getProperty_ID(){
        return Property_ID;
    }
     
    public int getSupervisor_ID(){
        return Supervisor_ID;
    }
     
    public int getMaximum_rent(){
        return Maximum_rent;
    }
     
    public int getRent_paid(){
        return Rent_paid;
    }
     
    public int getRent_due(){
        return Rent_due;
    }
    
  
    
}
